package com.example.demo.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

//@Controller
@RestController
public class TestRestController {

//    @RequestMapping(value = "/bonjour", method = RequestMethod.GET)
    @GetMapping("bonjour")
    public String bonjour(@RequestParam String auteur){
        return "Bonjour "+auteur;
    }
}
